"""SecureVault server: untrusted storage/relay over a length-prefixed,
JSON+base64 socket protocol (see network/codec.py).

The server never sees plaintext documents, plaintext Kdoc, plaintext
private keys, or passwords -- it only stores what clients already
protected before sending it.
"""

import socket
import threading
import struct

from network.codec import encode_message, decode_message
from server import storage

HOST = '127.0.0.1'
PORT = 65432


def handle_request(request: dict) -> dict:
    """Dispatch one decoded client request to the storage layer.

    This is the single source of truth for the client<->server
    protocol; ClientHandler just frames/deframes bytes around it.
    """

    if not isinstance(request, dict):
        return {"status": False, "message": "Malformed request"}

    action = request.get("type")

    try:
        if action == "REGISTER":
            username = request["username"]
            credential_record = request["credential_record"]
            stored = storage.save_user(username, credential_record)
            return {"status": stored}

        elif action == "GET_USER":
            username = request["username"]
            record = storage.get_user(username)
            if record is None:
                return {"status": False}
            return {"status": True, "credential_record": record}

        elif action == "UPLOAD_DOCUMENT":
            document_id = request["document_id"]
            owner_id = request["owner_id"]
            document = request["document"]
            filename = request["filename"]
            storage.save_document(document_id, document, owner_id, filename)
            return {"status": True}

        elif action == "DOWNLOAD_DOCUMENT":
            document_id = request["document_id"]
            record = storage.get_document_record(document_id)
            if record is None:
                return {"status": False}
            return {
                "status": True,
                "document": record["protected_document"],
                "filename": record["filename"],
            }

        elif action == "LIST_DOCUMENTS":
            owner_id = request["owner_id"]
            documents = storage.list_user_documents(owner_id)
            print("TEST DOCUMENTS:", documents)
            return {"status": True, "documents": documents}

        elif action == "SHARE":
            share_id = request["share_id"]
            share_record = request["share_record"]
            storage.save_share(share_id, share_record)
            return {"status": True}

        elif action == "GET_SHARES":
            shares = storage.get_all_shares()
            return {"status": True, "shares": shares}
        elif action == "TAMPER_DOCUMENT_TEST":
            document_id = request["document_id"]
            tampered = storage.tamper_document_for_test(document_id)
            return {"status": tampered}

        else:
            return {"status": False, "message": f"Unknown action: {action}"}

    except KeyError as exc:
        return {"status": False, "message": f"Missing field: {exc}"}


class ClientHandler(threading.Thread):
    def __init__(self, client_socket, client_address):
        super().__init__()
        self.client_socket = client_socket
        self.client_address = client_address

    def run(self):
        try:
            # Read 4-byte length header
            header = self.client_socket.recv(4)
            if not header:
                return

            request_length = struct.unpack('!I', header)[0]

            # Read exact payload
            request_bytes = bytearray()
            while len(request_bytes) < request_length:
                chunk = self.client_socket.recv(min(4096, request_length - len(request_bytes)))
                if not chunk:
                    raise ConnectionError("Connection lost while reading request")
                request_bytes.extend(chunk)

            # Decode request payload
            request_data = decode_message(bytes(request_bytes))

            # Route and handle request
            response = handle_request(request_data)

            # Encode and frame response
            serialized_response = encode_message(response)
            response_header = struct.pack('!I', len(serialized_response))
            self.client_socket.sendall(response_header + serialized_response)

        except Exception as e:
            print(f"Error handling client {self.client_address}: {e}")
            try:
                error_response = {'status': False, 'message': str(e)}
                serialized_error = encode_message(error_response)
                self.client_socket.sendall(struct.pack('!I', len(serialized_error)) + serialized_error)
            except Exception:
                pass
        finally:
            self.client_socket.close()


def run_server(host: str = HOST, port: int = PORT):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((host, port))
    server_socket.listen()
    print(f"SecureVault server listening on {host}:{port}")

    try:
        while True:
            client_socket, client_address = server_socket.accept()
            ClientHandler(client_socket, client_address).start()
    except KeyboardInterrupt:
        print("Shutting down server")
    finally:
        server_socket.close()


if __name__ == "__main__":
    run_server()
