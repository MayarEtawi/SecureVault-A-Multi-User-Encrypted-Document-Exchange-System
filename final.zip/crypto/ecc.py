# crypto/ecc.py
"""
NIST P-256 (secp256r1) elliptic-curve primitives.

Curve equation:   y^2 = x^3 + a*x + b  (mod p)

This module provides:
    - Point validation (is_on_curve, is_valid_public_key, is_valid_private_key)
    - Modular inverse
    - Point addition / doubling (point_add)
    - Scalar multiplication (scalar_multiply), implemented as a
      constant-time Montgomery ladder so that timing does not depend
      on the bits of the scalar (relevant when the scalar is a
      private key, e.g. in ECDH/ECDSA).
"""

from __future__ import annotations

# ============================================================
# NIST P-256 / secp256r1 Parameters
# ============================================================

p = 0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff

a = 0xffffffff00000001000000000000000000000000fffffffffffffffffffffffc

b = 0x5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604b

Gx = 0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296

Gy = 0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5

# Order of the generator point G (a prime; the group has cofactor 1).
n = 0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551


# ============================================================
# Point Representation
# ============================================================
# Normal point: (x, y), both ints in [0, p)
# Point at infinity: None

Point = tuple[int, int] | None

G: Point = (Gx, Gy)


# ============================================================
# Modular Arithmetic
# ============================================================

def mod_inverse(value: int, modulus: int = p) -> int:
    """
    Return the multiplicative inverse of value modulo `modulus`.

    The result x satisfies:
        value * x = 1 (mod modulus)

    `modulus` defaults to p because point arithmetic on the curve is
    performed in the base field GF(p). (Pass modulus=n if you ever
    need to invert something mod the group order instead, e.g. for
    ECDSA's k^-1.)
    """
    value %= modulus

    if value == 0:
        raise ZeroDivisionError("cannot invert 0 mod the given modulus")

    # modulus is prime, so Fermat's little theorem gives the inverse
    # directly: value^(modulus - 2) = value^-1 (mod modulus)
    return pow(value, modulus - 2, modulus)


# ============================================================
# Point Validation
# ============================================================

def is_on_curve(P: Point) -> bool:
    """
    Return True if P satisfies the P-256 curve equation:

        y^2 = x^3 + a*x + b (mod p)

    The point at infinity (None) is considered valid -- it's the
    group's identity element, even though it's not a curve solution.
    """
    if P is None:
        return True

    if not isinstance(P, tuple) or len(P) != 2:
        return False

    x, y = P

    # bool is a subclass of int in Python; reject it explicitly so
    # is_on_curve(True) etc. can't accidentally slip through.
    if (
        not isinstance(x, int) or isinstance(x, bool)
        or not isinstance(y, int) or isinstance(y, bool)
    ):
        return False

    if not (0 <= x < p and 0 <= y < p):
        return False

    left = (y * y) % p
    right = (pow(x, 3, p) + a * x + b) % p

    return left == right


def is_valid_public_key(Q: Point) -> bool:
    """
    Return True if Q is a valid public key on P-256, i.e. it is
    suitable to accept from another party in ECDH/ECDSA.

    A valid public key must:
        - be a well-formed point on the curve (is_on_curve), and
        - NOT be the point at infinity (infinity is not a usable key), and
        - belong to the correct subgroup of order n.

    P-256 has cofactor 1, so every point satisfying is_on_curve()
    (other than infinity) is already in the order-n subgroup, and
    n*Q == infinity for all of them. The scalar_multiply(n, Q) check
    below re-confirms group order and doubles as defense-in-depth
    against malformed/invalid-curve points, at negligible extra cost.
    """
    if Q is None:
        return False

    if not is_on_curve(Q):
        return False

    return scalar_multiply(n, Q) is None


def is_valid_private_key(d: int) -> bool:
    """
    Return True if d is a valid P-256 private key scalar.

    A valid private key must satisfy:
        1 <= d < n
    """
    if not isinstance(d, int) or isinstance(d, bool):
        return False

    return 1 <= d < n


# ============================================================
# Point Addition / Doubling
# ============================================================

def point_add(P: Point, Q: Point) -> Point:
    """
    Add two elliptic-curve points.

    Handles:
        P + O           (O = point at infinity)
        O + Q
        P + (-P)        -> O
        P + Q           (P != Q)
        P + P           (doubling)
    """
    if not is_on_curve(P) or not is_on_curve(Q):
        raise ValueError("cannot add a point that is not on the curve")

    if P is None:
        return Q
    if Q is None:
        return P

    x1, y1 = P
    x2, y2 = Q

    # P + (-P) = O  (same x, y values are negatives of each other mod p)
    if x1 == x2 and (y1 + y2) % p == 0:
        return None

    if x1 == x2 and y1 == y2:
        # Point doubling: m = (3*x1^2 + a) / (2*y1)
        if y1 == 0:
            return None
        m = ((3 * x1 * x1 + a) * mod_inverse(2 * y1)) % p
    else:
        # Standard addition: m = (y2 - y1) / (x2 - x1)
        m = ((y2 - y1) * mod_inverse(x2 - x1)) % p

    x3 = (m * m - x1 - x2) % p
    y3 = (m * (x1 - x3) - y1) % p

    result = (x3, y3)

    if not is_on_curve(result):
        # Defensive check -- should never trigger if the formulas above
        # are correct, but it catches implementation bugs early.
        raise ValueError("point addition produced a point off the curve")

    return result


# ============================================================
# Scalar Multiplication -- constant-time Montgomery ladder
# ============================================================
#
# WHY THIS SHAPE, IN PLAIN WORDS:
#
# The simplest way to compute k*P is "double-and-add": walk over each
# bit of k, always double, and only add P when the bit is 1. The
# problem is that the number of point_add() calls then depends on how
# many 1-bits k has. If k is a private key, someone measuring timing
# or power consumption can use that to recover k bit by bit -- a
# side-channel / timing attack.
#
# The Montgomery ladder fixes this by doing the *same* two point
# operations (one add, one double) on *every* bit, whether that bit
# is 0 or 1. Only which of two running values gets updated changes --
# not how much work is done -- so runtime no longer depends on k.
#
#   R0 -> (bits processed so far)      * P
#   R1 -> (bits processed so far + 1)  * P

def scalar_multiply(k: int, P: Point) -> Point:
    """
    Calculate k*P using a constant-time Montgomery ladder.

    Negative k is supported (k*P = |k| * (-P)); the internal ladder
    always runs over a non-negative exponent.
    """
    if not isinstance(k, int) or isinstance(k, bool):
        raise TypeError("k must be an integer")

    if not is_on_curve(P):
        raise ValueError("P is not a point on the P-256 curve")

    if P is None or k % n == 0:
        return None

    if k < 0:
        # -k * P = k * (-P), where -P = (x, -y mod p)
        k = -k
        x, y = P
        P = (x, (-y) % p)

    r0: Point = None   # 0 * P so far
    r1: Point = P       # 1 * P so far

    # Walk bits from most-significant to least-significant. Every bit
    # -- 0 or 1 -- costs exactly one point_add and one doubling, in a
    # fixed order, so the sequence of operations never reveals k.
    for i in range(k.bit_length() - 1, -1, -1):
        bit = (k >> i) & 1
        if bit == 0:
            r1 = point_add(r0, r1)
            r0 = point_add(r0, r0)
        else:
            r0 = point_add(r0, r1)
            r1 = point_add(r1, r1)

    if not is_on_curve(r0):
        raise ValueError("scalar multiplication produced a point off the curve")

    return r0


# ============================================================
# Simple Correctness Checks
# ============================================================

if __name__ == "__main__":

    print("Testing P-256 parameters...")

    print("G is on curve:", is_on_curve(G))
    print("G is a valid public key:", is_valid_public_key(G))

    # Important P-256 property: nG should equal the point at infinity.
    print("nG = infinity:", scalar_multiply(n, G) is None)

    # A few extra sanity checks against plain point_add.
    P2 = scalar_multiply(2, G)
    print("2G is on curve:", is_on_curve(P2))
    print("2G == G + G:", P2 == point_add(G, G))

    P3 = scalar_multiply(3, G)
    print("3G == 2G + G:", P3 == point_add(P2, G))

    # (n+1)G should equal G again.
    print("(n+1)G == G:", scalar_multiply(n + 1, G) == G)

    # Validation edge cases.
    print("infinity is a valid public key:", is_valid_public_key(None))       # False
    print("(0, 0) is a valid public key:", is_valid_public_key((0, 0)))        # False
    print("d=0 is a valid private key:", is_valid_private_key(0))             # False
    print("d=n is a valid private key:", is_valid_private_key(n))             # False
    print("d=n-1 is a valid private key:", is_valid_private_key(n - 1))       # True
