import base64
import dataclasses
import json

from pki.certificate import UserCertificate
from auth.private_key_protection import ProtectedPrivateKey
from crypto.key_wrap import WrappedDocumentKey
from crypto.sharing import ShareRecord


# Closed whitelist of application dataclasses allowed to cross the wire.
# Deliberately NOT a generic "reconstruct any class by name" mechanism --
# that would reopen the same arbitrary-deserialization risk pickle had.
# Only these known, safe, data-only classes may be rebuilt from network
# input, and only with exactly the fields each one declares.
_DATACLASS_REGISTRY = {
    "UserCertificate": UserCertificate,
    "ProtectedPrivateKey": ProtectedPrivateKey,
    "WrappedDocumentKey": WrappedDocumentKey,
    "ShareRecord": ShareRecord,
}


def _to_json_safe(value):
    """Convert Python values into JSON-safe values."""

    if isinstance(value, bytes):
        return {
            "__type__": "bytes",
            "data": base64.b64encode(value).decode("ascii")
        }

    if isinstance(value, bytearray):
        return {
            "__type__": "bytes",
            "data": base64.b64encode(bytes(value)).decode("ascii")
        }

    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        class_name = type(value).__name__
        if class_name not in _DATACLASS_REGISTRY:
            raise TypeError(
                f"Dataclass {class_name} is not registered for network transfer"
            )
        fields = {
            field.name: _to_json_safe(getattr(value, field.name))
            for field in dataclasses.fields(value)
        }
        return {
            "__type__": "dataclass",
            "class": class_name,
            "fields": fields,
        }

    if isinstance(value, dict):
        return {str(k): _to_json_safe(v) for k, v in value.items()}

    if isinstance(value, list):
        return [_to_json_safe(v) for v in value]

    # Tuples are tagged separately from lists (JSON has no tuple type,
    # and this codebase relies on tuple identity -- e.g. Point equality
    # checks like `public_key != certificate.ecdh_public_key` -- so a
    # plain list round-trip would silently break those comparisons).
    if isinstance(value, tuple):
        return {
            "__type__": "tuple",
            "items": [_to_json_safe(v) for v in value],
        }

    if value is None or isinstance(value, (str, int, float, bool)):
        return value

    raise TypeError(
        f"Unsupported network value type: {type(value).__name__}"
    )


def _from_json_safe(value):
    """Restore explicitly encoded binary values."""

    if isinstance(value, list):
        return [_from_json_safe(v) for v in value]

    if isinstance(value, dict):

        if set(value.keys()) == {"__type__", "data"}:

            if value["__type__"] != "bytes":
                raise ValueError("Unsupported encoded network type")

            try:
                return base64.b64decode(
                    value["data"],
                    validate=True
                )
            except Exception as exc:
                raise ValueError("Invalid base64 network value") from exc

        if set(value.keys()) == {"__type__", "items"}:

            if value["__type__"] != "tuple":
                raise ValueError("Unsupported encoded network type")

            return tuple(_from_json_safe(v) for v in value["items"])

        if set(value.keys()) == {"__type__", "class", "fields"}:

            if value["__type__"] != "dataclass":
                raise ValueError("Unsupported encoded network type")

            class_name = value["class"]
            target_class = _DATACLASS_REGISTRY.get(class_name)
            if target_class is None:
                raise ValueError(
                    f"Dataclass {class_name} is not registered for network transfer"
                )

            decoded_fields = {
                k: _from_json_safe(v) for k, v in value["fields"].items()
            }
            return target_class(**decoded_fields)

        return {
            k: _from_json_safe(v)
            for k, v in value.items()
        }

    return value


def encode_message(message: dict) -> bytes:
    """Encode a network message safely."""

    if not isinstance(message, dict):
        raise TypeError("Network message must be a dictionary")

    safe_message = _to_json_safe(message)

    return json.dumps(
        safe_message,
        separators=(",", ":"),
        sort_keys=True
    ).encode("utf-8")


def decode_message(data: bytes) -> dict:
    """Decode a network message safely."""

    try:
        decoded = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("Invalid network message") from exc

    message = _from_json_safe(decoded)

    if not isinstance(message, dict):
        raise ValueError("Network message must be a dictionary")

    return message