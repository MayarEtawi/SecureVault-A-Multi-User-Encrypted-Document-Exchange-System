import os
import json
from pathlib import Path
from pki.ca import generate_ca_keypair

# إنشاء المجلد إذا لم يكن موجوداً
Path("client").mkdir(exist_ok=True)

# توليد مفاتيح الـ CA
ca_private, ca_public = generate_ca_keypair()

# حفظ المفتاح العام في الملف المطلوب
pub_path = Path("client/trusted_ca_public.json")

# إذا كان المفتاح عبارة عن dictionary أو object يتم تحويله لـ JSON
try:
    from pki.ca import export_ca_public_key
    data = export_ca_public_key(ca_public)
except ImportError:
    data = json.dumps(ca_public) if isinstance(ca_public, dict) else str(ca_public)

if isinstance(data, dict):
    data = json.dumps(data)

pub_path.write_text(data, encoding="utf-8")
print("Successfully created client/trusted_ca_public.json!")