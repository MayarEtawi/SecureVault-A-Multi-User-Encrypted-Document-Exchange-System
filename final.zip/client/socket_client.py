import socket
import struct
from network.codec import encode_message, decode_message

HOST = '127.0.0.1'
PORT = 65432

def send_request(request_data):
    """
    Sends a dictionary request to the server and returns the server's response.
    Protocol: [4-byte length header] + [JSON/Base64 serialized payload]
    """
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        client_socket.connect((HOST, PORT))

        # Serialize request
        serialized_data = encode_message(request_data)

        # Prefix with 4-byte length header
        length_header = struct.pack('!I', len(serialized_data))
        client_socket.sendall(length_header + serialized_data)

        # Read 4-byte length header for response
        response_length_bytes = client_socket.recv(4)
        if not response_length_bytes:
            raise ConnectionError("Server closed connection unexpectedly")

        response_length = struct.unpack('!I', response_length_bytes)[0]

        # Read exact response payload
        response_bytes = bytearray()
        while len(response_bytes) < response_length:
            chunk = client_socket.recv(min(4096, response_length - len(response_bytes)))
            if not chunk:
                raise ConnectionError("Connection lost while receiving response")
            response_bytes.extend(chunk)

        # Deserialize response
        response_data = decode_message(bytes(response_bytes))
        return response_data

    finally:
        client_socket.close()